package com.tsdv.ManageElectricityBil.entity;

/**
 * @author bichdtn
 * set, get of attributes : name households, house Num, electric meter code
 */
public class Customer {
	private String nameCustomer;
	private String houseNum;
	private int electricMeterCode;

	public Customer() {

	}

	public Customer(String nameCustomer, String houseNum, int electricMeterCode) {
		this.nameCustomer = nameCustomer;
		this.houseNum = houseNum;
		this.electricMeterCode = electricMeterCode;
	}

	public String getNameCustomer() {
		return nameCustomer;
	}

	public void setNameCustomer(String nameCustomer) {
		this.nameCustomer = nameCustomer;
	}

	public String getHouseNum() {
		return houseNum;
	}

	public void setHouseNum(String houseNum) {
		this.houseNum = houseNum;
	}

	public int getElectricMeterCode() {
		return electricMeterCode;
	}

	public void setElectricMeterCode(int electricMeterCode) {
		this.electricMeterCode = electricMeterCode;
	}
	
	public void showInforCustomer() {
		System.out.println(">>		Customer Name      : " + nameCustomer);
		System.out.println(">> 		House Number       : " + houseNum);
		System.out.println(">>		Electric Meter Code: " + electricMeterCode);
	}
}
