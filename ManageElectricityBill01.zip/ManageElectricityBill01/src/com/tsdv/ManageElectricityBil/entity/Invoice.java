
package com.tsdv.ManageElectricityBil.entity;

/**
 * @author bichdtn
 * Information about the household using electricity, old electricity index, new electricity index, payable amount.
 * set, get attribute 
 */
public class Invoice {
	
	// create value ID autoincrement
	private static int autoincrementID = 0;
	private int id;
	private String houseNum;
	private int oldElectricityIn;
	private int newElectricityIn;
	private int moneyPay;

	public Invoice(String houseNum, int newElectricityIn, int oldElectricityIn) {
		this.id = autoincrementID;
		autoincrementID++;
		this.houseNum = houseNum;
		this.oldElectricityIn = oldElectricityIn;
		this.newElectricityIn = newElectricityIn;
		this.moneyPay = (newElectricityIn - oldElectricityIn) * 5;
	}

	public int getId() {
		return id;
	}

	public String getHouseNum() {
		return houseNum;
	}

	public int getOldElectricityIn() {
		return oldElectricityIn;
	}

	public void setOldElectricityIn(int oldElectricityIn) {
		this.oldElectricityIn = oldElectricityIn;
	}

	public int getNewElectricityIn() {
		return newElectricityIn;
	}

	public void setNewElectricityIn(int newElectricityIn) {
		this.newElectricityIn = newElectricityIn;
	}

	public int getMoneyPay() {
		return moneyPay;
	}

	/*
	 * This is method used display customer information(households)
	 */
	public void showInforInvoice() {
		System.out.println(">>		House Number            : " + houseNum);
		System.out.println(">> 		Old Electricity Index   : " + oldElectricityIn);
		System.out.println(">>		New Electricity Index   : " + newElectricityIn);
		System.out.println(">>      cost: " + moneyPay);
	}
}
