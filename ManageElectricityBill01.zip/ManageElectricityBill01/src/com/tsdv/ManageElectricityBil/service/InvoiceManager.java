package com.tsdv.ManageElectricityBil.service;

import java.util.ArrayList;
import java.util.List;

import com.tsdv.ManageElectricityBil.entity.Invoice;


/**
 * @author bichdtn
 *
 */
public class InvoiceManager {
	private List<Invoice> invoices = new ArrayList<Invoice>();

	public InvoiceManager(List<Invoice> invoices) {
		this.invoices = invoices;
	}

	public void addInvoice(Invoice invoice) {
		invoices.add(invoice);
	}

	private boolean isEmpty() {
		return invoices.size() == 0;
	}

	/*
	 * This is method used get invoice id in array
	 */
	public Invoice getInvoiceById(int id) {
		if (isEmpty()) {
			return null;
		} else {
			for (int i = 0; i < invoices.size(); i++) {
				if (invoices.get(i).getId() == id) {
					return invoices.get(i);
				}
			}
			return null;
		}
	}
	/*
	 * This is method used to delete invoice 
	 */
	public void deleteInvoice(int id) {
		if (isEmpty()) {
			System.out.println("You don't have any invoice");
		} else {
			for (int i = 0; i < invoices.size(); i++) {
				if (invoices.get(i).getId() == id) {
					invoices.remove(i);
					System.out.println("Delete invoice completed!");
					return;
				}
			}
			System.out.println("invoice is not exist");
		}
	}
	/*
	 * This is method used to display all invoice information
	 */
	public void displayAllInvoices() {
		if (isEmpty()) {
			System.out.println("No have any invoice");
			return;
		}
		for (int i = 0; i < invoices.size(); i++) {
			System.out.println("Invoice No." + invoices.get(i).getId());
			System.out.println("House number: "
					+ invoices.get(i).getHouseNum());
			System.out.println("Old index: "
					+ invoices.get(i).getOldElectricityIn());
			System.out.println("New index: "
					+ invoices.get(i).getNewElectricityIn());
			System.out.println("Cost: " + invoices.get(i).getMoneyPay());
			System.out.println();
		}
	}

}
