package com.tsdv.ManageElectricityBil.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.tsdv.ManageElectricityBil.entity.Customer;

public class CustomerManager {
	Scanner input = new Scanner(System.in);
	List<Customer> customers = new ArrayList<Customer>();

	public CustomerManager(List<Customer> customers) {
		this.customers = customers;
	}
	/**
	 * @author bichdtn
	 * This is method used to add new customer
	 * @param nameCustomer : This is name of customer
	 * @param houseNum     : This is house number of households
	 * @param electricMeterCode : This is electricity meter code of households
	 */
	public void addCustomer() {
		System.out.print(">>		Customer Name : ");
		String nameCustomer = input.nextLine();
		System.out.print(">> 		 House Number : ");
		String houseNum = input.nextLine();
		while (findCustomer(houseNum) != null) {
			System.out.print("The apartment num is exist, please try again: ");
			houseNum = input.nextLine();
		}
		System.out.print(">>  Electric Meter Code : ");
		int electricMeterCode = input.nextInt();
		input.nextLine();
		System.out.println();
		customers.add(new Customer(nameCustomer, houseNum,
				electricMeterCode));
	}

	/*
	 * This is method find house number of households
	 * @param houseNum : This is house number of households 
	 */
	public Customer findCustomer(String houseNum) {
		for (int i = 0; i < customers.size(); i++) {
			if (customers.get(i).getHouseNum().equals(houseNum)) {
				return customers.get(i);
			}
		}
		return null;
	}
	/*
	 * This is method edit household information
	 * @param houseNum : This is house number of households 
	 */
	public void editCustomer(String houseNum) {
		Customer customer = findCustomer(houseNum);
		if (customer == null) {
			System.out.println("The customer is not exist");
		} else {
			System.out.println("The old information");
			customer.showInforCustomer();
			System.out.println("Input your new information to edit");
			System.out.println("Customer name: ");
			String customerName = input.nextLine();
			System.out.println("Electric meter code: ");
			int electricMeterCode = input.nextInt();
			input.nextLine();
			customer.setElectricMeterCode(electricMeterCode);
			customer.setNameCustomer(customerName);
			System.out.println("Edit completed");
		}
	}
	/*
	 * This is method check array empty
	 */
	private boolean isEmpty() {
		return customers.size() == 0;
	}

	/*
	 * This is method delete household
	 */
	public void deleteCustomer(String houseNum) {
		for (int i = 0; i < customers.size(); i++) {
			if (customers.get(i).getHouseNum().equals(houseNum)) {
				customers.remove(i);
				System.out.println("Delete completed");
				return;
			}
		}
		System.out.println("The customer is not exist");
	}

	/*
	 * This is method display all customer(households)
	 */
	public void displayAllCustomer() {
		if (customers.size() == 0) {
			System.out.println("There are no customers to display!");
		} else {
			System.out
					.println("**************** List of households *****************");
			for (int i = 0; i < customers.size(); i++) {
				System.out.println("Customer No. " + (i + 1));
				customers.get(i).showInforCustomer();
				System.out.println();
			}
		}
	}
}
