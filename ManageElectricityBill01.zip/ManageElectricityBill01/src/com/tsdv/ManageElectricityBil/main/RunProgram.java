
/****************************************************************/
/* Copyright (C) 2011 TOSHIBA CORPORATION. All rights reserved. 
 * 
/* <h1 Manage electricity bill /h1>
 * Bill information : Information about the household using electricity, 
 *                    old electricity index, new index, payable amount.
 * Customer information : Name, Apartment Number, Electric meter code.
 * Request 1 : Create Customer class to store customer information. 
 * Request 2 : Create Invoice class to store invoice information.
 * Request 3 : Develop methods to add and delete specific information 
 *             of each household using electricity.
 * Request 4 : The method of calculating the electricity bill for each 
 *             household is based on the formula.
 *             
 * @author : Do Thi Ngung Bich
 * @version: 1.00
 * @since  : 2020 - 02 - 14
 */
/****************************************************************/

package com.tsdv.ManageElectricityBil.main;

import java.util.ArrayList;
import java.util.Scanner;

import com.tsdv.ManageElectricityBil.entity.Customer;
import com.tsdv.ManageElectricityBil.entity.Invoice;
import com.tsdv.ManageElectricityBil.service.CustomerManager;
import com.tsdv.ManageElectricityBil.service.InvoiceManager;

/**
 * @author bichdtn
 *
 */
public class RunProgram {
	
	Scanner input = new Scanner(System.in);
	Customer customer;
	Invoice invoice;

	ArrayList<Customer> customerList = new ArrayList<Customer>();
	ArrayList<Invoice>   invoiceList = new ArrayList<Invoice>();
	CustomerManager  customerManager = new CustomerManager(customerList);
	InvoiceManager    invoiceManager = new InvoiceManager(invoiceList);
	
	/*
	 * This is the method used to perform the functions in the program
	 * @param choose : This is the value entered from the keyboard perform the function
	 */
	public void play() {
		int choose;
		String houseNum;
		while (true) {
			showMenu();
			System.out.print("Enter your selection : ");
			choose = input.nextInt();
			input.nextLine();
			switch (choose) {
				case 1:
					customerManager.addCustomer();
					customerManager.displayAllCustomer();
					break;
				case 2:
					System.out.print("Enter the house number : ");
					houseNum = input.nextLine();
					customerManager.editCustomer(houseNum);
					break;
				case 3:
					System.out.print("Enter the house number : ");
					houseNum = input.nextLine();
					customerManager.deleteCustomer(houseNum);
					break;
				case 4:
					if (customerList.size() == 0) {
						System.out.println("No have any customer to add invoice");
						break;
					}
					System.out.print("Enter the house number : ");
					houseNum = input.nextLine();
					Customer customer = customerManager.findCustomer(houseNum);
					if (customer != null) {
						customer.showInforCustomer();
						System.out.print("Enter the old index: ");
						int oldIndex = input.nextInt();
						input.nextLine();
						System.out.print("Enter the new index: ");
						int newIndex = input.nextInt();
						input.nextLine();
						while (newIndex <= oldIndex) {
							System.out.print("The newIndex have to greater than oldIndex, please try again: ");
							newIndex = input.nextInt();
							input.nextLine();
						}
						invoiceManager.addInvoice(new Invoice(houseNum, newIndex, oldIndex));
						invoiceManager.displayAllInvoices();
					} else {
						System.out.println("The customer is not exist");
					}
					break;
				default:
					System.out.println("Your selection does not match. Please enter again!");
					System.out.println("Enter yours selection(from 1 to 4) : ");
					break;
			}
		}
	}
	/*
	 * This is method used to show selections : case 1, case 2, case 3 , case 4
	 */
	public void showMenu() {
		System.out.println("**************************************************");
		System.out.println("**             	  SHOW MENU                     **");
		System.out.println("**        1.Add Customer Information            **");
		System.out.println("**        2.Edit Customer Information           **");
		System.out.println("**        3.Delete Customer Information         **");
		System.out.println("**        4.Add Electric Invoice                **");
		System.out.println("**                                              **");
		System.out.println("**************************************************");
	}
	/*
	 * This is the main method which makes use of play method.
	 * @param args Unused. 
     * @return Nothing.
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RunProgram main = new RunProgram();
		main.play();
	}
}
