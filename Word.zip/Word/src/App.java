
public class App {

    public static void main(String[] args) {
        VanBan vanBan = new VanBan();

        vanBan.setSt("hoc hoc       nua hoc" + "    \n hoc hoc mai");
        System.out.println("So tu cua chuoi da cho la: " + vanBan.demTu(vanBan.getSt()));

        char c = 'A';
        vanBan.setSt("hom nay la thu bA ngay MAi la thu tu");
        System.out.println("So lan xuat hien cua ky tu" + c + "trong xau la: " + vanBan.demKyTu(vanBan.getSt(), c));

        vanBan.setSt("  DO THI   NGUNG BICH 1702    rlxđ     ");
        System.out.println("Xau da duoc chuan hoa thanh: " + vanBan.chuanHoa(vanBan.getSt()) + ".");
    }
}
