public class VanBan {

    private String st;

    public VanBan() {

    }

    public String getSt() {
        return st;
    }

    public void setSt(String st) {
        this.st = st;
    }

    public VanBan(String st) {
        this.st = st;
    }

    public int demTu(String input) {
        if (input == null) {
            return -1;
        }
        int count = 0;
        int size = input.length();
        boolean notCounted = true;
        for (int i = 0; i < size; i++) {
            if (input.charAt(i) != ' ' && input.charAt(i) != '\t'
                    && input.charAt(i) != '\n') {
                if(notCounted) {
                    count++;
                    notCounted = false;
                }
            } else {
                notCounted = true;
            }
        }
        return count;
    }

    public int demKyTu(String input, char c) {
        if (input == null) {
            return -1;
        }
        input = input.toUpperCase();
        int count = 0;
        int size = input.length();
        for (int i = 0; i < size; i++) {
            if (input.charAt(i) == c) {
                count++;
            }
        }
        return count;
    }

    public String chuanHoa(String input) {
        String str = input.trim();
        str = str.replaceAll("\\s+", " ");
        return str;
    }
}
